#include <stdio.h> 

int main(void){
	char entrada []  ="test";
	int i=0;
	
	printf("Cadena de entrada: %s\n", entrada);
	printf("Cadena de entrada en binario: ");


	while(entrada[i] != '\0'){
		int val_char = (int)entrada[i];
		int bits[8] = {0};
		int j = 7;
		
		while (val_char > 0) {
			bits[j] = val_char % 2;
			val_char = val_char / 2;
			j--;
			}
		int k = 0;
		while(k < 8){
			printf("%d", bits[k]);
			k++;
			}
		printf("\n");
		i++;
		} 


		printf("\n");
		return 0;
		
	}
